//
//  ViewController.swift
//  Dicee-iOS13
//
//  Created by Angela Yu on 11/06/2019.
//  Copyright © 2019 London App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var diceOne: UIImageView!
    @IBOutlet weak var diceTwo: UIImageView!
    
   //var r = arc4random() * 100

    
    
    @IBAction func roll_button_was_pressed(_ sender: Any) {
        
        let n =  [  #imageLiteral(resourceName: "DiceOne") ,  #imageLiteral(resourceName: "DiceTwo") , #imageLiteral(resourceName: "DiceThree") , #imageLiteral(resourceName: "DiceFour") ,#imageLiteral(resourceName: "DiceFive") , #imageLiteral(resourceName: "DiceSix")   ]
        
        
        diceOne.image = n.randomElement()
        diceTwo.image = n.randomElement()

        
     
        
    }
    override func viewDidLoad() {
        
     //   diceOne.alpha = 0.25
    
        super.viewDidLoad()
        diceTwo.image = #imageLiteral(resourceName: "DiceThree")  // image literal 
        // Do any additional setup after loading the view.
    }


}

